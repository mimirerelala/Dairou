function Player(name, lightColor, darkColor) {
    this.name= name;
    this.lightColor = lightColor;
    this.darkColor = darkColor;
    this.points = 0;
}
